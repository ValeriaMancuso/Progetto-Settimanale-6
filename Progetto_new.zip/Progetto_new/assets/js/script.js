var nome;
var cognome;
var addBtn;
var elencoHTML;
var errore;
var erroreElenco;
var elenco = [];
var toggle = true;
var modificaId = 0;


window.addEventListener('DOMContentLoaded', init);

function init() {
	nome = document.getElementById('nome');
	cognome = document.getElementById('cognome');
	addBtn = document.getElementById('scrivi');
	elencoHTML = document.getElementById('elenco');
	errore = document.getElementById('errore');
	erroreElenco = document.getElementById('erroreElenco');
	printData();
	eventHandler();
}

function eventHandler() {
	addBtn.addEventListener('click', function () {
		if (toggle == true){
			controlla();
		}
		else{
			esegui(modificaId);
		}
	});
	
}

function printData() {
	fetch('http://localhost:3000/elenco')
		.then((response) => {
			return response.json();
		})
		.then((data) => {
			elenco = data;
			if (elenco.length > 0) {
				errore.innerHTML = '';
				elencoHTML.innerHTML = '';
				elenco.map(function (element) {
					elencoHTML.innerHTML += `<li class="mb-1 fw-semibold text-light"><button type="button" class="btn btn-danger me-1" onClick="elimina(${element.id})"><i class="bi bi-x-circle"></i></button><button type="button" class="btn btn-success ms-2 me-2" onClick="modifica(${element.id}, '${element.nome}', '${element.cognome}')"><i class="bi bi-pen-fill"></i></button>${element.nome} ${element.cognome}</li>`;
				});
			} else {
				erroreElenco.innerHTML = 'Nessun elemento presente in elenco';
			}
		});
}

function controlla() {
	if (nome.value != '' && cognome.value != '') {
		var data = {
			nome: nome.value,
			cognome: cognome.value,
		};
		addData(data);
		
	} else {
		errore.innerHTML = 'Compilare correttamente i campi!';
		return;
	}
}

async function addData(data) {
	let response = await fetch('http://localhost:3000/elenco', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json;charset=utf-8',
		},
		body: JSON.stringify(data),
	});
	clearForm();
}

function clearForm() {
	nome.value = '';
	cognome.value = '';
}

function elimina(data) {

	if (!window.confirm('Sicuro di voler eliminare questo utente?')) {
		return;
	}

	fetch('http://localhost:3000/elenco/' + data, {
		method: 'DELETE'
		
	});
	
}


function modifica(dataId, dataName, dataSurname) {
	toggle = false;

	nome.value = dataName;
	cognome.value = dataSurname;
	modificaId = dataId;
	
	
}

async function esegui(modificaId) {
	if (nome.value == '' || cognome.value == '') {
		errore.innerHTML = 'Compilare correttamente i campi!';
		return;
	}

	if (!window.confirm('Sicuro di voler modificare questo utente?')) {
		return;
	}
	
	let data = {
		nome: nome.value,
		cognome: cognome.value,
	};
	let response = await fetch('http://localhost:3000/elenco/' + modificaId, {
		method: 'PUT',
		headers: {
			'Content-Type': 'application/json;charset=utf-8',
		},
		body: JSON.stringify(data),
	});
	
}
